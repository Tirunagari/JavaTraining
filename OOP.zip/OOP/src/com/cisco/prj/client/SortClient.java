package com.cisco.prj.client;

import com.cisco.prj.entity.Book;
import com.cisco.prj.entity.Mobile;
import com.cisco.prj.util.Utility;

public class SortClient {

	public static void main(String[] args) {

		Mobile[] mobiles = new Mobile[4];
		mobiles[0] = new Mobile(1, "Samsung", 35000.00, "4G");
		mobiles[1] = new Mobile(2, "Apple", 45000.00, "4G");
		mobiles[2] = new Mobile(3, "MI", 10000.00, "4G");
		mobiles[3] = new Mobile(4, "Moto", 15000.00, "4G");
		
		Utility.sort(mobiles);
		
		for (Mobile mobile : mobiles) {
			
			System.out.println(mobile);
		}
		
		Book[] books = new Book[4];
		books[0] = new Book("def", 25.0);	
		books[1] = new Book("xyz", 55.0);
		books[2] = new Book("abc", 45.0);
		books[3] = new Book("fgh", 65.0);
		
	    Utility.sort(books);
	    
	    for (Book book : books) {
			System.out.println(book);
		}
	}

}
