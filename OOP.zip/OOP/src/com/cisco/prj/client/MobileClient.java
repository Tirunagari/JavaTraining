package com.cisco.prj.client;

import com.cisco.prj.dao.MobileDao;
import com.cisco.prj.dao.MobileDaoFactory;
import com.cisco.prj.entity.Mobile;

public class MobileClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MobileDao mobileDao = MobileDaoFactory.getMobileDao();
		Mobile m = new Mobile(1,"Apple", 25000.00, "3G");
		mobileDao.addMobile(m);
		

	}

}
