package com.cisco.prj.client;

import com.cisco.prj.entity.Account;

public class AccountClient {

	public static void main(String[] args) {

		Account first = new Account();
		Account second = new Account("ICIC246");
		Account third = new Account("ICIC246");
		Account fourth = first;
		if(fourth == first) {
			
			System.out.println("Fourth and First are equal");
		}
		
		if(third.equals(second)) {
			
			System.out.println("Third and secound are equal");
		}
		
		first.deposit(3000.00);
		second.deposit(4500.00);
		second.withdraw(250.00);
		System.out.println("First A/C");
		System.out.println("Balance of " + first.getAccountNumber() + ": " + first.getBalance());
		System.out.println("Second A/C");
		System.out.println("Balance of " + second.getAccountNumber() + ": " + second.getBalance());
		System.out.println("Total Accounts are: " + Account.getCount());
	}
	
	

}
