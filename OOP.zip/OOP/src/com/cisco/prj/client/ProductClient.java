package com.cisco.prj.client;

import com.cisco.prj.entity.Mobile;
import com.cisco.prj.entity.Product;
import com.cisco.prj.entity.Tv;

public class ProductClient {

	public static void main(String[] args) {
    Product[] products = new Product[4];
    products[0] = new Mobile(1, "Apple", 6000.00, "3G");
    products[1] = new Tv(2, "LG", 45000.00, "led");
    products[2] = new Mobile(3, "Samsung", 25000.00, "4G");
    products[3] = new Tv(4, "Sony", 7500.00, "lcd");
    
    for (int i = 0; i < products.length; i++) {
    	
    	System.out.println(products[i].getName() + "," + products[i].getPrice());
    	if(products[i].isExpensive()) {
    		
    		System.out.println("This is expensive!");
    		
    		
    	}
    	
    	if(products[i] instanceof Mobile) {
			
			Mobile m = (Mobile) products[i];
			System.out.println(m.getConnectivity());
		}
		
		if(products[i].getClass() == Tv.class) {
			Tv t = (Tv) products[i];
			System.out.println(t.getScreen());
			
		}
    	
    	System.out.println("*********************");
		
	}
    
		
	}

}
