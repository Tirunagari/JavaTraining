/**
 * 
 */
package com.cisco.prj.entity;

/**
 * @author vtirunag
 * @version 1.0
 * @since FEB 13
 * Entity class which contains account details
 */
public class Account {
	
	private double balance;
	private String accNo;
	private static int count; // This is called class member
	/**
	 * Default Constructor
	 */
	
	public Account() {
		
		this.accNo = "NA";
		count++;
		
	}
	
	/**
	 * Paramterized constructor
	 * @param accNo
	 */
	public Account(String accNo) {
		this.accNo = accNo;
		count++;
	}
	
	/**
	 * 
	 * @param amt amount to be credited
	 */
	public void deposit(double amt) {
		
		this.balance += amt;
	}
	
	/**
	 * 
	 * @param amt amount to be debited
	 */
	public void withdraw(double amt) {
		
		this.balance -= amt;
	}
	
	/**
	 * 
	 * @return current balance
	 */
	public double getBalance() {
		
		return this.balance;
	}

	public String getAccountNumber() {
		
		return this.accNo;
	}
	
	public static int getCount() {
		
		return count;
	}

    @Override
	public boolean equals(Object obj) {
		Account A = (Account)obj;
    	boolean equals = false;
		
		if(this.accNo.equalsIgnoreCase(A.accNo)) {
			
			equals = true;
		}
		
		return equals;
		
		
	}

	
	
	

}
