/**
 * 
 */
package com.cisco.prj.entity;

import com.cisco.prj.util.IComparable;

/**
 * @author vtirunag
 *
 */
public class Mobile extends Product implements IComparable {

	 private String connectivity;

	/**
	 * 
	 */
	public Mobile() {
		
	}

	/**
	 * @param id
	 * @param name
	 * @param price
	 * @param connectivity
	 */
	public Mobile(int id, String name, double price, String connectivity) {
		super(id, name, price);
		this.connectivity = connectivity;
	}

	/**
	 * @return the connectivity
	 */
	public String getConnectivity() {
		return connectivity;
	}

	/**
	 * @param connectivity the connectivity to set
	 */
	public void setConnectivity(String connectivity) {
		this.connectivity = connectivity;
	}

	/* (non-Javadoc)
	 * @see com.cisco.prj.entity.Product#isExpensive()
	 */
	@Override
	public boolean isExpensive() {
	     if("3G".equals(this.connectivity) && getPrice() > 7500.00) {
	    	 
	    	 return true;
	     } else if("4G".equals(this.connectivity) && getPrice() > 15000.00) {
	    	 
	    	 return true;
	     }
	     
	     return false;
	     
	}

	@Override
	public int difference(Object obj) {
		Mobile other = (Mobile) obj;
		if(this.getPrice() == other.getPrice())
		   return 0;
		
		return this.getPrice() > other.getPrice() ? 1:-1;
				   
	   
		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Mobile [getId()=" + getId() + ", getName()=" + getName() + ", getPrice()=" + getPrice()
				+ ", connectivity=" + connectivity + "]";
	}
	
	 
	 
}
