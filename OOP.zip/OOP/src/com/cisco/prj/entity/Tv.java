/**
 * 
 */
package com.cisco.prj.entity;

/**
 * @author vtirunag
 *
 */
public class Tv extends Product {
	
	private String screen;

	/**
	 * Default Constructor
	 */
	public Tv() {
	}

	/**
	 * @param id
	 * @param name
	 * @param price
	 * @param screen
	 */
	public Tv(int id, String name, double price, String screen) {
		super(id, name, price);
		this.screen = screen;
	}

	/**
	 * @return the screen
	 */
	public String getScreen() {
		return screen;
	}

	/**
	 * @param screen the screen to set
	 */
	public void setScreen(String screen) {
		this.screen = screen;
	}

	/* (non-Javadoc)
	 * @see com.cisco.prj.entity.Product#isExpensive()
	 */
	@Override
	public boolean isExpensive() {
		if("lcd".equals(this.screen) && getPrice() > 10000) {
			
			return true;
		} else if ("led".equals(this.screen) && getPrice() > 25000) {
			return true;
		} else if("crt".equals(this.screen) && getPrice() > 3000) {
			return true;
		}
		
		return false;
	}
	
	
	

}
