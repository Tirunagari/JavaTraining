package com.cisco.prj.dao;

import com.cisco.prj.entity.Mobile;

public class MobileDaoCloudImp implements MobileDao {

	@Override
	public void addMobile(Mobile mobile) {
       System.out.println("Implements storing in cloud " + mobile.getName());
	}

}
