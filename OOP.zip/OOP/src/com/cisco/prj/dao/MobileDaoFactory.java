/**
 * 
 */
package com.cisco.prj.dao;

import java.util.ResourceBundle;

/**
 * @author vtirunag
 *
 */
public class MobileDaoFactory {
	
	private static String DAO_CLASS="";
	
	//Executes only once when class is loaded
	static {
		ResourceBundle res = ResourceBundle.getBundle("dbconfig");
		DAO_CLASS = res.getString("MOBILE_DAO").trim();
		
	}
	
	
	
	
	public static MobileDao getMobileDao() {
		
		try {
			//Loose coupling: creates an object 
			return (MobileDao) Class.forName(DAO_CLASS).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	//	return new MobileDaoCloudImp();
	}

}
