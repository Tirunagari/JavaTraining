/**
 * 
 */
package com.cisco.prj.dao;

import com.cisco.prj.entity.Mobile;

/**
 * @author vtirunag
 *
 */
public interface MobileDao {
	
	/**
	 * Method to add Mobile in storage
	 * @param mobile
	 *              Mobile to be added
	 */
	void addMobile(Mobile mobile);
	

}
