package com.cisco.prj.dao;

import com.cisco.prj.entity.Mobile;

public class MobileDaoDbImpl implements MobileDao {

	@Override
	public void addMobile(Mobile mobile) {

		System.out.println("Store this into RDBM table " + mobile.getName());
	}

}
